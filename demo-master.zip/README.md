# demo
boot学习案列

初次提交
maven install打包  
运行java -server -jar x.jar

整合swagger

配置logback日志
