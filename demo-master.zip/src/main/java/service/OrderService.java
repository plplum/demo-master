package service;

import com.example.demo.bean.Order;

public interface OrderService {
	
    public Order getOrderById(int orderId);

    boolean addOrder(Order order);

}