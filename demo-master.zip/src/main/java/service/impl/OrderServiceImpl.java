package service.impl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.bean.Order;
import com.example.demo.dao.OrderMapper;

import service.OrderService;


@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
    private OrderMapper orderDao;

	@Override
	public Order getOrderById(int orderId) {
		return orderDao.selectByPrimaryKey(orderId);
	}

	@Override
	public boolean addOrder(Order order) {
		boolean result = false;
        try {
        	orderDao.insertSelective(order);
            result = true;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
	}

}