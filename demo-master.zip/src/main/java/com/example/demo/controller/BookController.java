package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.bean.Order;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import service.OrderService;

@Api(tags="Book Info Controller")
@RestController
@RequestMapping(value = "/book")
public class BookController {
	
	
	@Autowired
	private OrderService orderService;
	
	@GetMapping
	@ApiOperation("查询详细信息")
	public String index() {
		return "hello book";
	}

	
	@ResponseBody
	@RequestMapping(value = "/getOrder")
	public Order getOrder() {
		Order stu = orderService.getOrderById(1);
		return stu;
	}

	
}
